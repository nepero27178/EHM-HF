#!/usr/bin/julia
using DelimitedFiles
using DataFrames

@doc raw"""
function GetLabels(
	Phase::String
)::Dict{String,String}

Returns: LaTeX formatted variable labels.
"""
function GetLabels(
	Phase::String
)::Dict{String,String}

	if in(Phase, ["AF", "FakeAF"])
		VarLabels = Dict([
			"t" => "t",
			"U" => "U",
			"Lx" => "L_x",
			"δ" => "\\delta",
			"β" => "\\beta",
			"m" => "m",
			"w0" => "w^{(\\mathbf{0})}",
			"wp" => "w^{(\\bm{\\pi})}"
		])
	elseif Phase=="Fake"
		VarLabels = Dict([
			"g" => "g"
		])
	end

	return VarLabels

end

@doc raw"""
function PlotOrderParameter(
	Phase::String,
	FilePathIn::String,
	DirPathOut::String;
	xVar::String=\"U\",
	pVar::String=\"δ\",
	Skip::Int64=1,
	cs::Symbol=:imola50,
	RenormalizeHopping::Bool=true,
	Extension::String="pdf"::String="pdf"
)

Returns: none (plots saved at `DirPathOut`).

`PlotOrderParameter` takes as input `Phase` (string specifying the mean-field
phase, the allowed are \"AF\", \"FakeAF\", \"SU/Singlet\", \"SU/Triplet\"), 
`FilePathIn` (path to the data files), `DirPathOut` (path to the output
directory). The optional parameters are `xVar` and `pVar` (strings specifying
respectively the x variable and the parametric variable of the plot, the 
allowed are \"t\", \"U\", \"Lx\", \"δ\", \"β\"), `Skip` (integer indicating 
how many steps in the parametric variable to be skipped between two plots), 
`cs` (colorscheme symbol). `Extension` selects the file extension (the allowed
are \"pdf\", \"png\", \"svg\").
"""
function PlotOrderParameter(
	Phase::String,						# Mean field phase
	FilePathIn::String,					# Data filepath
	DirPathOut::String;					# Output directory path
	xVar::String="U",					# Specify x variable
	pVar::String="δ",					# Specify parametric variable
	Skip::Int64=1,						# xVar skip parameter
	cs::Symbol=:imola50,				# Custom colorscheme
	RenormalizeHopping::Bool=true,		# Conditional renormalization of t
	Extension::String="pdf"				# File extension
)

	FilePathOut = ""
	AllVars = ["t", "U", "Lx", "δ", "β"]

	# Input safecheck
	if !in(xVar, AllVars)
		@error "Invalid x variable, choose one of $(AllVars)"
		exit()
	end

	if !in(pVar, AllVars)
		@error "Invalid parametric variable, choose one of $(AllVars)"
		exit()
	end

	if xVar==pVar
		@error "You have chosen xVar=pVar!"
		exit()
	end

	# Get LaTeX formatted labels
	VarLabels = GetLabels(Phase)

	# Initialize directory structure
	DirPathOut *= "PlotOrderParameter/xVar=" * xVar * "/pVar=" * pVar * "/"
	mkpath(DirPathOut)

	# Read data and create DataFrame
	DataIn = open(FilePathIn) do io
		readdlm(FilePathIn, ';', comments=false, '\n')
	end
	DF = DataFrame(DataIn[2:end,:], DataIn[1,:])
	select!(DF, Not(:V)) # Filter outa data from V=0.0
	DF.Lx = Int64.(DF.Lx)

	# Unique variables dictionary
	uDict::Dict{String,Vector{Any}} = Dict([
		Var => unique(DF[!, Symbol(Var)]) for Var in AllVars
	])

	uDict[xVar] = [NaN]					# Remove from following cycle
	JJ::Vector = uDict[pVar][1:Skip:end]
	uDict[pVar] = [NaN]					# Remove from following cycle
	q = floor(Int64, length(colorschemes[cs]) / length(JJ) )

	# Check if the selected colorscheme is large enough
	if q==0
		@error "Your cs (ColorScheme) is not large enough. Select another."
		exit()
	end

	# List HF parameters
	ListHFPs::Vector{String} = [key for key in keys(
		eval(Meta.parse(
			DF.v[1]
		))
	)]

	# Cycle over HF parameters
	for HF in ListHFPs

		HFLabel::String = "\$" * VarLabels[HF] * "\$"
		if HF=="m"
			HFLabel = "Magnetization"
		end

		# Cycle over simulated points
		for (w,t) in enumerate(uDict["t"]),
			(u,U) in enumerate(uDict["U"]),
			(l,L) in enumerate(uDict["Lx"]),
			(d,δ) in enumerate(uDict["δ"]),
			(b,β) in enumerate(uDict["β"])

			# Initialize local dictionary
			lDict::Dict{String,Any} = Dict([
				"t" => t,
				"U" => U,
				"Lx" => L,
				"δ" => δ,
				"β" => β
			])

			# Select entries
			Selections::Vector{Bool} = [true for _ in 1:length(DF.t)]
			for Var in AllVars
				if !in(Var, [xVar, pVar])
					"""
					Selections = Selections .* (DF[Var] .== lDict[Var])
					"""
					Selections = Selections .* (DF[!, Symbol(Var)] .== lDict[Var])
				end
			end

			# Initialize plot
			P = plot(
				size = (600,400),
				xlabel = L"$%$(VarLabels[xVar])$",
				ylabel = L"$%$(VarLabels[HF])$",
				legend = :outertopright,
			)

			# Write terminal message and file name
			TerminalMsg::String = "\e[2K\e[1GPlotting $(Phase) HF $(HF) data: "
			FilePathOut::String = DirPathOut * "/" * HF
			rawTitle::String = HFLabel * " ("

			AvoidList::Vector{String} = [xVar, pVar]
			for Var in AllVars
				if !in(Var, AvoidList)
					lVar = lDict[Var]
					TerminalMsg *= Var * "=$(lVar), "
					FilePathOut *= "_" * Var * "=$(lVar)"
					RS::String=""
					if !RenormalizeHopping && Var=="t"
						RS *= "\\tilde{t}="
					end
					rawTitle *= "\$$(VarLabels[Var])=" * RS * "$(lVar)\$, "
					if Var=="Lx" # I am desperate about correct formatting
						rawTitle = rawTitle[1:end-5] * "\$, "
					elseif Var=="β" && β==Inf
						rawTitle = rawTitle[1:end-6] * "\\infty\$, "
					end
				end
			end
			TerminalMsg = TerminalMsg[1:end-2] * " [x variable: " * xVar *
				", parametric variable: " * pVar * "]"
			FilePathOut *= "." * Extension
			rawTitle *= "varying \$" * VarLabels[pVar] * "\$)"
			printstyled("\e[2K\e[1G" * TerminalMsg, color=:yellow)

			# Cycle over parametric variable
			for (j,J) in enumerate(JJ)

				# Run local selection
				lSelections = Selections .* (DF[!, Symbol(pVar)] .== J)
				vv = DF.v[lSelections]

				# Define x and y variables
				xx::Vector{Float64} = DF[!, Symbol(xVar)][lSelections]
				yy::Vector = [eval(Meta.parse(
					vv[i]
				))[HF] for i in 1:length(vv)]

				# Plot parametrically
				plot!(
					xx, yy,
					markershape = :circle,
					markercolor = colorschemes[cs][q*j],
					markersize = 1.5,
					linecolor = colorschemes[cs][q*j],
					label = L"$%$(VarLabels[pVar])=%$(J)$",
					legendfonthalign = :left
				)
				title!(L"%$(rawTitle)")
			end

			# Save figure
			Plots.PGFPlotsX.push_preamble!(
				backend_object(P).the_plot, "\\usepackage{bm}"
			)
			savefig(P, FilePathOut)
		end
	end
	printstyled("\e[2K\e[1GDone! Plots saved at $(DirPathOut)\n", color=:green)
end

@doc raw"""
function PlotOrderParameter2D(
	Phase::String,
	FilePathIn::String,
	DirPathOut::String;
	xVar::String=\"U\",
	yVar::String=\"δ\",
	cs::Symbol=:imola50,
	Extension::String="pdf"
)

Returns: none (plots saved at `DirPathOut`).

`PlotOrderParameter2D` takes as input `Phase` (string specifying the mean-field
phase, the allowed are \"AF\", \"FakeAF\", \"SU/Singlet\", \"SU/Triplet\"), 
`FilePathIn` (path to the data files), `DirPathOut` (path to the output 
directory). The optional parameters are `xVar` and `yVar` (strings specifying 
respectively the x variable and the y variable of the plot, the allowed are 
\"t\", \"U\", \"Lx\", \"δ\", \"β\"), `cs` (colorscheme symbol). `Extension` 
selects the file extension (the allowed are \"pdf\", \"png\", \"svg\").
"""
function PlotOrderParameter2D(
	Phase::String,						# Mean field phase
	FilePathIn::String,					# Data filepath
	DirPathOut::String;					# Output directory path
	xVar::String="U",                   # Specify x variable
	yVar::String="δ",                   # Specify y variable
	cs::Symbol=:imola50,                # Custom colorscheme
	Extension::String="pdf"             # File extension
)

	FilePathOut = ""
	AllVars = ["t", "U", "Lx", "δ", "β"]

	# Input safecheck
	if !in(xVar, AllVars)
		@error "Invalid x variable, choose one of $(AllVars)"
		exit()
	end

	if !in(yVar, AllVars)
		@error "Invalid parametric variable, choose one of $(AllVars)"
		exit()
	end

	if xVar==yVar
		@error "You have chosen xVar=yVar!"
		exit()
	end

	# Get LaTeX formatted labels
	VarLabels = GetLabels(Phase)

	# Initialize directory structure
	DirPathOut *= "Heatmaps/xVar=" * xVar * "_yVar=" * yVar * "/"
	mkpath(DirPathOut)

	# Read data and create DataFrame
	DataIn = open(FilePathIn) do io
		readdlm(FilePathIn, ';', comments=false, '\n')
	end
	DF = DataFrame(DataIn[2:end,:], DataIn[1,:])
	select!(DF, Not(:V)) # Filter outa data from V=0.0
	DF.Lx = Int64.(DF.Lx)

	# Unique variables dictionary
	uDict::Dict{String,Vector{Any}} = Dict([
		Var => unique(DF[!, Symbol(Var)]) for Var in AllVars
	])

	xx::Vector{Float64} = uDict[xVar]
	NumX::Int64 = length(xx)
	uDict[xVar] = [NaN]                   # Remove from following cycle
	yy::Vector{Float64} = uDict[yVar]
	NumY::Int64 = length(yy)
	uDict[yVar] = [NaN]                   # Remove from following cycle

	# List HF parameters
	ListHFPs::Vector{String} = [key for key in keys(
		eval(Meta.parse(
			DF.v[1]
		))
	)]

	# Cycle over HF parameters
	for HF in ListHFPs

		HFLabel::String = "\$" * VarLabels[HF] * "\$"
		if HF=="m"
			HFLabel = "Magnetization"
		end

		# Cycle over simulated points
		for (w,t) in enumerate(uDict["t"]),
			(u,U) in enumerate(uDict["U"]),
			(l,L) in enumerate(uDict["Lx"]),
			(d,δ) in enumerate(uDict["δ"]),
			(b,β) in enumerate(uDict["β"])

			# Initialize local dataframe
			lDict::Dict{String,Any} = Dict([
				"t" => t,
				"U" => U,
				"Lx" => L,
				"δ" => δ,
				"β" => β
			])

			# Select entries
			Selections::Vector{Bool} = [true for _ in 1:length(DF.t)]
			for Var in AllVars
				if !in(Var, [xVar, yVar])
					Selections = Selections .* (DF[!, Symbol(Var)] .== lDict[Var])
				end
			end

			# Initialize plot
			H = plot(
				size = (600,400),
				xlabel = L"$%$(VarLabels[xVar])$",
				ylabel = L"$%$(VarLabels[yVar])$",
				legend = :outertopright
			)

			# Write terminal message and file name
			TerminalMsg::String = "\e[2K\e[1GPlotting $(Phase) HF $(HF) data: "
			FilePathOut::String = DirPathOut * "/" * HF
			rawTitle::String = HFLabel * " ("
			for Var in AllVars
				if !in(Var, [xVar, yVar])
					lVar = lDict[Var]
					TerminalMsg *= Var * "=$(lVar), "
					FilePathOut *= "_" * Var * "=$(lVar)"
					RS::String=""
					if !RenormalizeHopping && Var=="t"
						RS *= "\\tilde{t}="
					end
					rawTitle *= "\$$(VarLabels[Var])=" * RS * "$(lVar)\$, "
					if Var=="Lx" # I am desperate about correct formatting
						rawTitle = rawTitle[1:end-5] * "\$, "
					elseif Var=="β" && β==Inf
						rawTitle = rawTitle[1:end-6] * "\\infty\$, "
					end
				end
			end
			TerminalMsg = TerminalMsg[1:end-2] * " [x variable: " * xVar *
				", y variable: " * yVar * "]"
			FilePathOut *= "." * Extension
			rawTitle = rawTitle[1:end-2] * ")"
			printstyled("\e[2K\e[1G" * TerminalMsg, color=:yellow)

			# Define x, y variables and h
			vv = DF.v[Selections]
			hh::Matrix{Float64} = zeros(NumY,NumX)
			for j in 1:NumX
				hh[:,j] .= [eval(Meta.parse(
					vv[(j-1) * NumY + i]
				))[HF] for i in 1:NumY]
			end

			# Plot parametrically
			heatmap!(
				xx, yy, hh,
				color=cs
			)
			title!(L"%$(rawTitle)")

			# Save figure
			Plots.PGFPlotsX.push_preamble!(
				backend_object(H).the_plot, "\\usepackage{bm}"
			)
			savefig(H, FilePathOut)
		end
	end
	printstyled("\e[2K\e[1GDone! Plots saved at $(DirPathOut)\n", color=:green)
end

@doc raw"""
function PlotRecord(
	Phase::String,
	DirPathIn::String,
	DirPathOut::String;
	rVar::String=\"g\",
	cs::Symbol=:imola25,
	Extension::String="pdf"
)

Returns: none (plots saved at `DirPathOut`).

`PlotRecord` takes as input `Phase` (string specifying the mean-field phase, the
allowed are \"AF\", \"FakeAF\", \"SU/Singlet\", \"SU/Triplet\"), `FilePathIn` (path
to the data files), `DirPathOut` (path to the output directory). The optional 
parameter is `rVar` (string specifying the recorded variable to plot), `cs`
(colorscheme symbol). `Extension` selects the file extension (the allowed are 
\"pdf\", \"png\", \"svg\").
"""
function PlotRecord(
	Phase::String,                      # Mean field phase
	DirPathIn::String,                  # Data filepath
	DirPathOut::String;                 # Output directory path
	rVar::String="g",                   # Recorded variable
	cs::Symbol=:imola25,                # Custom colorscheme
	Extension::String="pdf"             # File extension
)

	Files::Vector{String} = readdir(DirPathIn)
	rFiles::Dict{Float64,String} = Dict([])
	DataCols::Vector{String} = [""]

	# Check data structure and extract r values
	for (j,F) in enumerate(Files)
		FilePathIn::String = DirPathIn * "/" * F
		eqIndex::Int64 = findfirst('=', F)
		if F[1:eqIndex-1]==rVar

			# Read header
			Header = open(FilePathIn) do io
				readdlm(FilePathIn, ';', '\n')[1]
			end
			Start = findfirst('[',Header)
			Stop = findfirst(']',Header)
			if j==1
				DataCols = eval(Meta.parse( Header[Start:Stop] ))
			elseif j>1
				if DataCols != eval(Meta.parse( Header[Start:Stop] ))
					@error "Bad data structure (DataCols inconsistent). " *
						"Check data integrity at " * DirPathIn
					exit()
				end
			end
			r = parse(Float64, F[eqIndex+1:end-4]) # Remove .txt
			rFiles[r] = FilePathIn

		elseif F[1:eqIndex-1]!=rVar
			@error "Bad data structure (rVar not found). " *
				"Check data integrity at " * DirPathIn
			exit()
		end
	end

	# Get LaTeX formatted labels
	VarLabels = GetLabels(Phase)
	pVarLabels = GetLabels("Fake")

	for (hf,HF) in enumerate(DataCols)

		HFLabel::String = "\$" * VarLabels[HF] * "\$"
		if HF=="m"
			HFLabel = "Magnetization"
		end

		# Set output filepath
		FilePathOut::String = DirPathOut * "/" * HF * "_rVar=" * rVar
		FilePathOut*= "." * Extension

		# Generate raw title
		rawTitle::String = HFLabel * " (" *
			"\$t=$(t)\$, " *
			"\$U=$(U)\$, " *
			"\$V=$(V)\$, " *
			"\$L=$(L)\$, " *
			"\$\\delta=$(δ)\$, "

		if β==Inf
			rawTitle *= "\$\\beta=\\infty\$)"
		elseif β!=Inf
			rawTitle *= "\$\\beta=$(β)\$)"
		end

		# Initialize plot
		P = plot(
			size = (600,400),
			xlim = (1,25),
			xlabel = L"\mathrm{Step}",
			ylabel = L"$%$(VarLabels[HF])$",
			legend = :outertopright
		)
		title!(L"%$(rawTitle)")

		# Cycle over data
		for (j,r) in enumerate( sort([key for key in keys(rFiles)]) )

			# Generate FilePathIn
			FilePathIn = rFiles[r]

			# Read and assign variables
			DataIn = open(FilePathIn) do io
				readdlm(FilePathIn, ';', comments=true, '\n')
			end

			yy = DataIn[:,hf]
			LineStyle = :solid
			if length(yy)>100
				yy = yy[1:100]
				LineStyle = :dash
			end
			xx = [x for x in 1:length(yy)]
			plot!(
				xx,yy,
				markershape = :circle,
				markercolor = colorschemes[cs][j],
				markersize = 1.5,
				linestyle = LineStyle,
				linecolor = colorschemes[cs][j],
				label = L"$%$(pVarLabels[rVar])=%$(r)$",
			)

		end

		# Save figure
		Plots.PGFPlotsX.push_preamble!(
			backend_object(P).the_plot, "\\usepackage{bm}"
		)
		savefig(P, FilePathOut)
	end
	printstyled("\e[2K\e[1GDone! Plots saved at $(DirPathOut)\n", color=:green)
end
